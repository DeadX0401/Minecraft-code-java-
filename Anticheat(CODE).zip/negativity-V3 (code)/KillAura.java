import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AntiKillAuraPlugin extends JavaPlugin implements Listener {

    private Map<UUID, Long> lastAttackTimes = new HashMap<>();
    private long attackCooldownMillis = 1000; // Adjust as needed

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            Player victim = (Player) event.getEntity();

            if (isSuspiciousAttack(attacker)) {
                // Cancel the attack event
                event.setCancelled(true);
                // You can add additional actions here, such as logging or punishment
                attacker.sendMessage("You are not allowed to use kill aura on this server.");
            }
        }
    }

    private boolean isSuspiciousAttack(Player attacker) {
        long currentTime = System.currentTimeMillis();
        UUID attackerUUID = attacker.getUniqueId();

        if (lastAttackTimes.containsKey(attackerUUID)) {
            long lastAttackTime = lastAttackTimes.get(attackerUUID);
            if (currentTime - lastAttackTime < attackCooldownMillis) {
                // Player attacked too quickly, possibly using kill aura
                return true;
            }
        }

        // Update last attack time
        lastAttackTimes.put(attackerUUID, currentTime);
        return false;
    }
}
