import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiXrayPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (isXrayMaterial(block.getType())) {
            // Prevent breaking of Xray material, you can also perform other actions here
            event.setCancelled(true);
        }
    }

    private boolean isXrayMaterial(Material material) {
        switch (material) {
            case DIAMOND_ORE:
            case GOLD_ORE:
            case IRON_ORE:
            case LAPIS_ORE:
            case REDSTONE_ORE:
            case EMERALD_ORE:
            case COAL_ORE:
                return true;
            default:
                return false;
        }
    }
}
