import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class AntiFlyPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // Run a task periodically to check for flying players
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.isFlying()) {
                        // Player is flying, cancel flight
                        player.setFlying(false);
                        player.setVelocity(new Vector(0, -1, 0)); // Move player down
                        player.sendMessage("Flying is not allowed on this server.");
                        // You can add additional actions here, such as logging or punishment
                    }
                }
            }
        }.runTaskTimer(this, 0, 20 * 5); // Check every 5 seconds (adjust as needed)
    }
}
